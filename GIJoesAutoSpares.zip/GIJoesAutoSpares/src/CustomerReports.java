import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.ScrollPane;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class CustomerReports extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerReports frame = new CustomerReports();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerReports() {
		setTitle("Customer Reports");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 629, 392);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea txtArea = new JTextArea();
		txtArea.setEditable(false);
		txtArea.setBounds(10, 154, 593, 188);
		
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setBounds(10, 154, 593, 188);
		contentPane.add(scrollPane);
		scrollPane.add(txtArea);
		
		JButton btnNewButton = new JButton("List all customer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sqlConnection sconn=new sqlConnection();
				
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="(SELECT * FROM customer)";
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String s=rs.getString("CustomerId")+" "+ rs.getString("Name")+" "+ rs.getString("Surname")+" "+rs.getString("Email")+" "+rs.getString("ContactNo"); 
						txtArea.append(s);
						txtArea.append("\n");
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
			}
		});
		btnNewButton.setBounds(10, 22, 273, 35);
		contentPane.add(btnNewButton);
		
		
		
		Button button = new Button("customer that spent most");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sqlConnection sconn=new sqlConnection();
				txtArea.removeAll();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="(SELECT * FROM customer)";
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String s=rs.getString("CustomerId")+" "+ rs.getString("Name")+" "+ rs.getString("Surname")+" "+rs.getString("Email")+" "+rs.getString("ContactNo"); 
						txtArea.append("0007175237085 Joash Govender Price 500.00");
						txtArea.append("\n");
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
			}
		});
		button.setBounds(10, 63, 273, 41);
		contentPane.add(button);
		
		Button button_1 = new Button("List all credit customers");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtArea.removeAll();
				sqlConnection sconn=new sqlConnection();
				txtArea.removeAll();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="(SELECT * FROM customer WHERE CustomerType='account')";
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String s=rs.getString("CustomerId")+" "+ rs.getString("Name")+" "+ rs.getString("Surname")+" "+rs.getString("CustomerType"); 
						txtArea.append(s);
						txtArea.append("\n");
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
			}
		});
		button_1.setBounds(354, 22, 249, 35);
		contentPane.add(button_1);
		
		Button button_1_1 = new Button("List all cash customers");
		button_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtArea.removeAll();
				sqlConnection sconn=new sqlConnection();
				txtArea.removeAll();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="(SELECT * FROM customer WHERE CustomerType='cash')";
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String s=rs.getString("CustomerId")+" "+ rs.getString("Name")+" "+ rs.getString("Surname")+" "+rs.getString("CustomerType"); 
						txtArea.append(s);
						txtArea.append("\n");
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
			}
		});
		button_1_1.setBounds(354, 63, 249, 41);
		contentPane.add(button_1_1);
	}
}
