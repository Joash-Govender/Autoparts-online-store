import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class AdminLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private String username,password;
	//HARDCODE ADMIN DETAILS
	private String AdminUser="Admin123",Adminpassword="1234";
	private JTextField txtDisplay;
	
	

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		setTitle("Admin Login");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtDisplay = new JTextField();
		txtDisplay.setForeground(Color.RED);
		txtDisplay.setEditable(false);
		txtDisplay.setColumns(10);
		txtDisplay.setBounds(102, 121, 221, 27);
		contentPane.add(txtDisplay);
		
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(0, 51, 92, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setBounds(0, 90, 92, 14);
		contentPane.add(lblNewLabel_1);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(102, 45, 221, 27);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(102, 84, 221, 27);
		contentPane.add(txtPassword);
		
		JButton btnNewButton = new JButton("Log in");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				username=txtUsername.getText();
				password=txtPassword.getText();
				if(username.equals(AdminUser) && password.equals(Adminpassword)) {
					txtDisplay.setForeground(Color.green);
					txtDisplay.setText("Correct");
					AdminHome adh=new AdminHome();
					adh.newScreen();
				}
				else {
					txtDisplay.setForeground(Color.red);
					txtDisplay.setText("Incorrect username or password");
				}
				
			}
		});
		btnNewButton.setBounds(102, 159, 221, 27);
		contentPane.add(btnNewButton);
		
		
	}
}
