import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;
import java.awt.Color;

public class CustomerShop extends JFrame {

	private JPanel contentPane;
	private JTextField txtSearch;
	private JTextField txtTotal;
	private String id,password,filter="";
	private int partNo[]=new int[100];
	private static int countArray=0;
	private static int countButtonClicked=0;
	private static double total=0;
	private static int partsOrdered[]=new int[100];

	/**
	 * Launch the application.
	 */
	public Connection databaseConnect() {
		
		sqlConnection sconn=new sqlConnection();
		
		
		try {
			
			Connection conn=sconn.getConnection();
			return conn;
			
			}
			
			
			catch (Exception e1) {
				// TODO: handle exception
				System.out.println("something went wrong");
				e1.printStackTrace();
				return null;
			}
		
		
		
	};
	
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerShop frame = new CustomerShop();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerShop() {
		setTitle("Customer Shop");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 1000, 550);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		DefaultComboBoxModel cb=new DefaultComboBoxModel();
		JComboBox cmbOptions = new JComboBox(cb);
		cmbOptions.setToolTipText("Options");
		cmbOptions.setBounds(895, 11, 79, 22);
		contentPane.add(cmbOptions);
		cmbOptions.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(cmbOptions.getSelectedIndex()==1) {
					CustomerDetails cd =new CustomerDetails();
					cd.newScreen();
				}
				else if(cmbOptions.getSelectedIndex()==2) {
					CustomerOrders co=new CustomerOrders();
					co.newScreen();
				}
			}
		});
		cb.addElement("Options");
		cb.addElement("My details");
		cb.addElement("My orders");
		
		
		txtSearch = new JTextField();
		txtSearch.setBounds(28, 43, 480, 20);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		
		
		
		JLabel lblNewLabel = new JLabel("Filter By:");
		lblNewLabel.setBounds(28, 74, 53, 14);
		contentPane.add(lblNewLabel);
		
		JRadioButton rgbtPart = new JRadioButton("PartNo");
		rgbtPart.setBounds(76, 70, 65, 23);
		contentPane.add(rgbtPart);
		
		JRadioButton rgbtMake = new JRadioButton("Make");
		rgbtMake.setBounds(143, 70, 53, 23);
		contentPane.add(rgbtMake);
		
		JRadioButton rgbtModel = new JRadioButton("model");
		rgbtModel.setBounds(205, 70, 65, 23);
		contentPane.add(rgbtModel);
		
		JRadioButton rgbtDescription = new JRadioButton("Dscription");
		rgbtDescription.setBounds(266, 70, 109, 23);
		contentPane.add(rgbtDescription);
		ButtonGroup group=new ButtonGroup();
		group.add(rgbtDescription);
		group.add(rgbtMake);
		group.add(rgbtModel);
		group.add(rgbtPart);
		

		//cart list
				ScrollPane scrollPane_1 = new ScrollPane();
				scrollPane_1.setBounds(798, 54, 182, 194);
				contentPane.add(scrollPane_1);
				

				final DefaultListModel<String> modelCart = new DefaultListModel<>();
				final JList<String> lstCart = new JList<>(modelCart);
				lstCart.setValueIsAdjusting(true);
				lstCart.setBounds(798, 54, 182, 194);
						//contentPane.add(list1);
				lstCart.setVisibleRowCount(15);
				lstCart.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						//list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION) ;
			    scrollPane_1.add(lstCart);	  
		
		
		
		
		JButton btnNewButton_1 = new JButton("Remove Item");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedIndex=lstCart.getSelectedIndex();
				if(selectedIndex<0) {
					 JOptionPane.showMessageDialog(null,
				                "Please select a item to delete",
				                "PopUp Dialog",
				                JOptionPane.INFORMATION_MESSAGE);
					
				}
				else if(selectedIndex>=0) {
					
					total-=150;
					modelCart.removeElementAt(selectedIndex);
					txtTotal.setText(Double.toString(total));
				}
			}
		});
		btnNewButton_1.setBounds(844, 300, 130, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Clear Cart");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modelCart.clear();;
				total=0;
				txtTotal.setText(Double.toString(total));
			}
		});
		btnNewButton_1_1.setBounds(844, 334, 130, 23);
		contentPane.add(btnNewButton_1_1);
		
		txtTotal = new JTextField();
		txtTotal.setBounds(844, 269, 130, 20);
		contentPane.add(txtTotal);
		txtTotal.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Total:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(798, 273, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Place Order");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,
		                "Order successfully placed",
		                "PopUp Dialog",
		                JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_2.setBounds(844, 373, 130, 23);
		contentPane.add(btnNewButton_2);
		
			    
		//results list
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setBounds(28, 108, 579, 179);
		contentPane.add(scrollPane);
		
		final DefaultListModel<String> modelResults = new DefaultListModel<>();
		final JList<String> lstResults = new JList<>(modelResults);
	    lstResults.setValueIsAdjusting(true);
	    lstResults.setBounds(28, 108, 579, 179);
				//contentPane.add(list1);
	    lstResults.setVisibleRowCount(15);
	   lstResults.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				//list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION) ;
	    scrollPane.add(lstResults);	  
	    
	    //listener for selecting items to add to cart
	    lstResults.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				int arrayPartNo=partNo[lstResults.getSelectedIndex()];
				if(countButtonClicked==0) {
					countButtonClicked=1;
				}
				String query="SELECT PartNo,CarModel,Description,Price FROM part WHERE PartNo="+arrayPartNo+"";
				Statement stmt;
				try {
					stmt = databaseConnect().createStatement();
					
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						partNo[countArray]=rs.getInt("PartNo");
						String s=rs.getString("PartNo")+" "+ rs.getString("CarModel")+" "+rs.getString("Description")+" "+rs.getDouble("Price"); 
						total+=rs.getDouble("Price");
						modelCart.add(count,s);
						countArray++;
						count++;
						}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				txtTotal.setText(Double.toString(total));
			}
		});
		
		
	    
		JLabel lblNewLabel_2 = new JLabel("Cart");
		lblNewLabel_2.setBounds(798, 34, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.setBounds(518, 42, 89, 23);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			modelResults.clear();
			countButtonClicked++;
				
				String query="(SELECT * FROM part)";
				String search=txtSearch.getText();
				if(rgbtDescription.isSelected()) {
					filter="Description";
					query="(SELECT * FROM part ORDER BY Description DESC)";
				}
				else if(rgbtMake.isSelected()) {
					filter="Make";
					query="(SELECT * FROM part ORDER BY CarMake DESC)";
				}
				else if(rgbtModel.isSelected()) {
					filter="Model";
					query="(SELECT * FROM part ORDER BY CarModel DESC)";
				}
				else if(rgbtPart.isSelected()) {
					filter="PartNo";
					query="(SELECT * FROM part ORDER BY PartNo DESC)";
				}
				else {
					filter="";
					query="(SELECT * FROM part)";
					
				}
				
				//populate result list
				
				
				Statement stmt;
				try {
					stmt = databaseConnect().createStatement();
					
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						partNo[countArray]=rs.getInt("PartNo");
						String s=rs.getString("PartNo")+" "+ rs.getString("CarMake")+" "+ rs.getString("CarModel")+" "+rs.getString("Description")+" "+rs.getDouble("price"); 
					
						modelResults.add(count,s);
						countArray++;
						count++;
						}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//write query
				
			}
			
			
			
			
		});
		
	}
}
