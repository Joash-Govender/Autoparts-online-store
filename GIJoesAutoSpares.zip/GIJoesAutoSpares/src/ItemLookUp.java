import java.awt.BorderLayout;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.Color;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JCheckBoxMenuItem;
import java.awt.List;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import java.awt.Panel;
import javax.swing.JEditorPane;
import java.awt.ScrollPane;
import javax.swing.JInternalFrame;
import javax.swing.ListSelectionModel;

public class ItemLookUp extends JFrame {

	private JPanel contentPane;
	private JTextField txtSearch;
	private JTable table;
	private String searchInput;
	private static String [] spart=new String[100];
	private  String [] selected=new String[100];
	private static int countSelected=0;
	private JTextField txtTotal;
	private static double total=0;
	private static double price=0;
	private int index=0;
	private double priceSelected[]=new double[100];
	
	

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ItemLookUp frame = new ItemLookUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ItemLookUp() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 811, 457);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Search part");
		lblNewLabel.setBounds(26, 68, 89, 23);
		contentPane.add(lblNewLabel);
		
		txtSearch = new JTextField();
		txtSearch.setBounds(132, 69, 319, 20);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("Search Results");
		lblNewLabel_1.setBounds(26, 127, 89, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Selected Item");
		lblNewLabel_2.setBounds(26, 276, 99, 23);
		contentPane.add(lblNewLabel_2);
		
		table = new JTable();
		table.setBounds(174, 387, 405, -88);
		contentPane.add(table);
		
		JPanel panel = new JPanel();
		panel.setBounds(81, 102, 553, 23);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JRadioButton rbtDesc = new JRadioButton("Description");
		rbtDesc.setSelected(true);
		rbtDesc.setBounds(6, 0, 109, 23);
		panel.add(rbtDesc);
		
		JRadioButton rbtMake = new JRadioButton("Make");
		rbtMake.setBounds(111, 0, 109, 23);
		panel.add(rbtMake);
		
		JRadioButton rbtModel = new JRadioButton("Model");
		rbtModel.setBounds(222, 0, 109, 23);
		panel.add(rbtModel);
		
		JRadioButton rbtBrand = new JRadioButton("Brand");
		rbtBrand.setBounds(333, 0, 109, 23);
		panel.add(rbtBrand);
		
		JRadioButton rbtPart = new JRadioButton("Part No");
		rbtPart.setBounds(444, 0, 109, 23);
		panel.add(rbtPart);
		ButtonGroup group=new ButtonGroup();
		group.add(rbtDesc);
		group.add(rbtMake);
		group.add(rbtModel);
		group.add(rbtBrand);
		group.add(rbtPart);
		
		
		JLabel lblNewLabel_3 = new JLabel("Search By:");
		lblNewLabel_3.setBounds(26, 102, 105, 23);
		contentPane.add(lblNewLabel_3);
		
		
		
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setBounds(125, 131, 489, 119);
		contentPane.add(scrollPane);
		
		ScrollPane scrollPane_1 = new ScrollPane();
		scrollPane_1.setBounds(125, 276, 489, 119);
		contentPane.add(scrollPane_1);
		 
		//try code
		//JList list1 = new JList();
		final DefaultListModel<String> model = new DefaultListModel<>();
	    final JList<String> list1 = new JList<>(model);
	    list1.setValueIsAdjusting(true);
		list1.setBounds(132, 387, 489, -95);
		//contentPane.add(list1);
		list1.setVisibleRowCount(5);
		list1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION) ;
	      scrollPane.add(list1);
	      
	      	//JList list2 = new JList(selected);
	     // final DefaultListModel<String> model2 = new DefaultListModel<>();
	      final DefaultListModel<String> model2 = new DefaultListModel<>();
	      final JList<String> list2 = new JList<>(model2);
	      list2.setValueIsAdjusting(true);
	      list2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			list2.setBounds(130, 387, 474, -107);
			scrollPane_1.add(list2);
			
	     
		
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				sqlConnection sconn=new sqlConnection();
				
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="(SELECT * FROM part)";
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String s=rs.getString("PartNo")+" "+ rs.getString("CarMake")+" "+ rs.getString("CarModel")+" "+rs.getString("Description")+" "+rs.getDouble("price"); 
						spart[count]=s;
						model.add(count,s);
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}

				
					
				list1.addListSelectionListener(new ListSelectionListener() {
					
					@Override
					public void valueChanged(ListSelectionEvent e) {
						//to display selected items in list 2
						index=list1.getSelectedIndex()+1;
						int count=0;
						selected[countSelected]=spart[list1.getSelectedIndex()];
						model2.addElement(list1.getSelectedValue());
						//model2.add(countSelected,list1.getSelectedValue());
						
						
						//get total of quoted items

						try {
							
							Connection conn=sconn.getConnection();
							//create a statement object
							Statement stmt=conn.createStatement();
							//write query
							String query="(SELECT Price FROM part WHERE PartNo="+index+")";
							//execute query
							
							ResultSet rs    = stmt.executeQuery(query);
							while(rs.next()) {
								 price=rs.getDouble("Price"); 
								 priceSelected[countSelected]=price;
								System.out.println(priceSelected[countSelected]);
								 
							}
							 count++;
							total+=price;
						}
							
						catch (Exception e1) {
								// TODO: handle exception
								System.out.println("something went wrong");
								e1.printStackTrace();
							}
							
													
						//String regex="([0-9])*";
//						Pattern r = Pattern.compile(regex);
//						Matcher m = r.matcher(list1.getSelectedValue());

//
//						String price=m.group(0);
//						total+=Float.parseFloat(price);
						countSelected++;
						txtTotal.setText(Double.toString(total));;
					}
				});
				
				
				
			}
			
		});
		btnSearch.setBounds(475, 68, 89, 23);
		contentPane.add(btnSearch);
		
		JButton btnNewButton = new JButton("remove item");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedIndex=list2.getSelectedIndex();
				if(selectedIndex<0) {
					 JOptionPane.showMessageDialog(null,
				                "Please select a item to delete",
				                "PopUp Dialog",
				                JOptionPane.INFORMATION_MESSAGE);
					
				}
				else if(selectedIndex>=0) {
					
					total-=priceSelected[selectedIndex];
					model2.removeElementAt(selectedIndex);
					txtTotal.setText(Double.toString(total));
				}
			}
		});
		btnNewButton.setBounds(620, 276, 128, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("clear list");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model2.clear();;
				total=0;
				txtTotal.setText(Double.toString(total));
			}
		});
		btnNewButton_1.setBounds(620, 310, 128, 23);
		contentPane.add(btnNewButton_1);
		
		txtTotal = new JTextField();
		txtTotal.setText("0.00");
		txtTotal.setBounds(620, 375, 128, 20);
		contentPane.add(txtTotal);
		txtTotal.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Total of Quoted items");
		lblNewLabel_4.setBounds(620, 350, 128, 14);
		contentPane.add(lblNewLabel_4);
			
								
								
							
							
							
							
							
								
							
							
						
							
							
							

		
		
		
		
		
		
		
		
		
		
	
	
		
		
		
	
		
		
		
	}
}
