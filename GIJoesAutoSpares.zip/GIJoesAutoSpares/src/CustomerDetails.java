import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class CustomerDetails extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtName;
	private JTextField txtSurname;
	private JTextField txtEmail;
	private JTextField txtContact;
	private JTextField txtAddress;
	private JTextField txtCustomerType;
	private JTextField txtPassword;
	private JTextField txtRetype;
	private String ID;

	/**
	 * Launch the application.
	 */
	public void getDetails() {
		sqlConnection sconn=new sqlConnection();
		
		try {
			
			Connection conn=sconn.getConnection();
			//create a statement object
			Statement stmt=conn.createStatement();
			//write query
			String query="SELECT * FROM customer";
			//execute query
			
			ResultSet rs    = stmt.executeQuery(query);
			while(rs.next()) {
				String cusId=rs.getString("CustomerId");
				
				if(cusId=="0007175237085") {
					txtId.setText(ID);
					 txtName.setText(rs.getString("Name"));
					 txtSurname.setText(rs.getString("Surname"));
					 txtEmail.setText(rs.getString("Email"));
					 txtContact.setText(rs.getString("ContactNo"));
					 txtPassword.setText(rs.getString("Password"));
					 txtAddress.setText(rs.getString("Address"));
					 txtCustomerType.setText(rs.getString("CustomerType"));
				}
				
				 
			}
			 
		}
			
		catch (Exception e1) {
				// TODO: handle exception
				System.out.println("something went wrong");
				e1.printStackTrace();
			}
		
	}
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerDetails frame = new CustomerDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerDetails() {
		CustomerLogin cl=new CustomerLogin();
		ID=cl.getID();
		getDetails();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 571, 443);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Number");
		lblNewLabel.setBounds(10, 45, 120, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 80, 120, 14);
		contentPane.add(lblName);
		
		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setBounds(10, 110, 120, 14);
		contentPane.add(lblSurname);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(10, 139, 120, 14);
		contentPane.add(lblEmail);
		
		JLabel lblContactNumber = new JLabel("Contact Number");
		lblContactNumber.setBounds(10, 171, 120, 14);
		contentPane.add(lblContactNumber);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(10, 206, 120, 14);
		contentPane.add(lblAddress);
		
		JLabel lblCustomertype = new JLabel("CustomerType");
		lblCustomertype.setBounds(10, 244, 120, 14);
		contentPane.add(lblCustomertype);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 278, 120, 14);
		contentPane.add(lblPassword);
		
		JLabel lblRetypePassword = new JLabel("Retype Password");
		lblRetypePassword.setBounds(10, 311, 120, 14);
		contentPane.add(lblRetypePassword);
		
		txtId = new JTextField();
		txtId.setEditable(false);
		txtId.setBounds(140, 42, 279, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		txtName = new JTextField();
		txtName.setEditable(false);
		txtName.setColumns(10);
		txtName.setBounds(140, 77, 279, 20);
		contentPane.add(txtName);
		
		txtSurname = new JTextField();
		txtSurname.setEditable(false);
		txtSurname.setColumns(10);
		txtSurname.setBounds(140, 107, 279, 20);
		contentPane.add(txtSurname);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(140, 136, 279, 20);
		contentPane.add(txtEmail);
		
		txtContact = new JTextField();
		txtContact.setColumns(10);
		txtContact.setBounds(140, 168, 279, 20);
		contentPane.add(txtContact);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(140, 203, 279, 20);
		contentPane.add(txtAddress);
		
		txtCustomerType = new JTextField();
		txtCustomerType.setEditable(false);
		txtCustomerType.setColumns(10);
		txtCustomerType.setBounds(140, 241, 279, 20);
		contentPane.add(txtCustomerType);
		
		txtPassword = new JTextField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(140, 275, 279, 20);
		contentPane.add(txtPassword);
		
		txtRetype = new JTextField();
		txtRetype.setColumns(10);
		txtRetype.setBounds(140, 308, 279, 20);
		contentPane.add(txtRetype);
		
		JButton btnNewButton = new JButton("Update Details");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email,contact,password,retype,address;
				email=txtEmail.getText();
				contact=txtContact.getText();
				password=txtPassword.getText();
				retype=txtRetype.getText();
				address=txtAddress.getText();
				
				if (password.equals(retype) && password!="" && retype!="" && address!="" && contact.length()==10 &&email!="") {
					
					
					try {
						sqlConnection sconn=new sqlConnection();
						Connection conn=sconn.getConnection();
						
						
						String query="UPDATE customer SET Address=?,ContactNo =?,Password=?,Email=? WHERE CustomerId =?";
						// Create the Prepared Statement
						PreparedStatement ps = conn.prepareStatement(query);
						ps.setString(1, address);
						ps.setString(2, contact);
						ps.setString(3, password);
						ps.setString(4, email);
						ps.setString(5, ID);
						
						int rowsAffected = ps.executeUpdate();
						System.out.format("Number of rows affected: %d", rowsAffected);
						JOptionPane.showMessageDialog(null,
				                "Details Updated",
				                "PopUp Dialog",
				                JOptionPane.INFORMATION_MESSAGE);
						getDetails();
						
					}
				 catch (Exception e1) {
					// TODO: handle exception
					System.out.println("something went wrong");
					e1.printStackTrace();
				}
					
				}
				else {
					JOptionPane.showMessageDialog(null,
			                "Please ensure no details are left blank and password matches retyped password ",
			                "PopUp Dialog",
			                JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnNewButton.setBounds(138, 354, 281, 23);
		contentPane.add(btnNewButton);
	}
}
