import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import java.awt.Color;

public class CustomerOrders extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerOrders frame = new CustomerOrders();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerOrders() {
		setTitle("Customer Orders");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 583, 325);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea txtArea = new JTextArea();
		txtArea.setBounds(10, 46, 547, 229);
		contentPane.add(txtArea);

		txtArea.append("OrderId"+ "\t" +"Parts"+ "\t"+ "Total"+ "\t" +"Date" +"\t"+ "DeliveryId");
		txtArea.append("\n");
		txtArea.append("1"+ "\t" +"Brake pads"+ "\t"+ "500"+ "\t" +"2022/22/06" +"\t"+ "1");
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

}
