import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class EmployeeLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdNumber;
	private JTextField txtPassword;
	private JTextField txtDisplay;
	private static String IdNum;
	private static String Password;

	/**
	 * Launch the application.
	 */
	public String getId() {
		return IdNum;
	}
	
	public String getPassword() {
		return Password;
	}
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeLogin frame = new EmployeeLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeLogin() {
		setTitle("Employee Login");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Number");
		lblNewLabel.setBounds(10, 80, 80, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(10, 129, 80, 14);
		contentPane.add(lblNewLabel_1);
		
		txtIdNumber = new JTextField();
		txtIdNumber.setBounds(100, 77, 245, 20);
		contentPane.add(txtIdNumber);
		txtIdNumber.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(100, 126, 245, 20);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);
		
		txtDisplay = new JTextField();
		txtDisplay.setEditable(false);
		txtDisplay.setColumns(10);
		txtDisplay.setBounds(100, 167, 245, 20);
		contentPane.add(txtDisplay);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IdNum=txtIdNumber.getText();
				IdNum.replaceAll("\\s", "");
				Password=txtPassword.getText();
				Password.replaceAll("\\s", "");
				System.out.println("input  "+IdNum+" "+Password);
				sqlConnection sconn=new sqlConnection();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="SELECT EmployeeId,Password  FROM employee";
					//execute query
					ResultSet rs=stmt.executeQuery(query);
					
					//display results
					
					
					
					
					while (rs.next()) {
						String empID=rs.getString("EmployeeId");
						String empPassword=rs.getString("Password");
						empID.replaceAll("\\s", "");
						empPassword.replaceAll("\\s", "");
						System.out.println(empID+" "+empPassword);
						
						
						
						if (IdNum.equals(empID) ){
							if (Password.equals(empPassword) ) {
								txtDisplay.setForeground(Color.green);
								txtDisplay.setText("Correct!!!");
								
								EmployeeHome eh=new EmployeeHome();
								eh.newScreen();
								break;
								
							}
							
							
						}
						else {
							txtDisplay.setForeground(Color.red);
							txtDisplay.setText("Id number or password Incorrect");
							
							
							
						}
					
						
						
					}
					
					} catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
			}
			
		});
		btnNewButton.setBounds(100, 207, 237, 23);
		contentPane.add(btnNewButton);
	}

}
