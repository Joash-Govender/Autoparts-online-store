import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EmployeeDetails extends JFrame {

	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtBranch;
	private JTextField txtName;
	private JTextField txtSurname;
	private JTextField txtAddress;
	private JTextField txtContact;
	private JTextField txtPassword;
	private JTextField txtRetype;
	private String ID;
	private String password;
	private String name;
	private String surname;
	private String address;
	private int branch;
	private String contact;
	private String retype;
	

	/**
	 * Launch the application.
	 */
	public void getDetails(String id,String Password) {
		id=this.ID;
		Password=this.password;
		sqlConnection sconn=new sqlConnection();
		try {
			
			Connection conn=sconn.getConnection();
			//create a statement object
			Statement stmt=conn.createStatement();
			//write query
			String query="SELECT * FROM employee";
			//execute query
			ResultSet rs=stmt.executeQuery(query);
			
			//display results
			
			
			
			
			while (rs.next()) {
				String empID=rs.getString("EmployeeId");
				String empPassword=rs.getString("Password");
				
				
				
				
				
				if (id.equals(empID) ){
					
						name=rs.getString("Name");
						surname=rs.getString("Surname");
						address=rs.getString("Address");
						contact=rs.getString("ContactNumber");
						branch=(rs.getInt("BranchId"));
						txtName.setText(name);
						txtSurname.setText(surname);
						txtAddress.setText(address);
						txtContact.setText(contact);
						txtBranch.setText(Integer.toString(branch));
						txtID.setText(id);
						txtPassword.setText(Password);
						break;
						
						
					
					
					
				}
				else if(!(id.equals(empID))) {
					JOptionPane.showMessageDialog(null,
			                "Cannot find employee info ",
			                "PopUp Dialog",
			                JOptionPane.INFORMATION_MESSAGE);
					
					
					
				}
			
				
				
			}
			
			} catch (Exception e1) {
				// TODO: handle exception
				System.out.println("something went wrong");
				e1.printStackTrace();
			}
	};
	
	public void updateDetails() {
		address=txtAddress.getText();
		contact=txtContact.getText();
		password=txtPassword.getText();
		retype=txtRetype.getText();
		
		if (password.equals(retype) && password!="" && retype!="" && address!="" && contact.length()==10) {
			
			
			try {
				sqlConnection sconn=new sqlConnection();
				Connection conn=sconn.getConnection();
				
				
				String query="UPDATE employee SET Address=?,ContactNumber=?,Password=? WHERE EmployeeId=?";
				// Create the Prepared Statement
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setString(1, address);
				ps.setString(2, contact);
				ps.setString(3, password);
				ps.setString(4, ID);
				
				int rowsAffected = ps.executeUpdate();
				System.out.format("Number of rows affected: %d", rowsAffected);
				JOptionPane.showMessageDialog(null,
		                "Details Updated",
		                "PopUp Dialog",
		                JOptionPane.INFORMATION_MESSAGE);
				getDetails(ID, password);
				
			}
		 catch (Exception e1) {
			// TODO: handle exception
			System.out.println("something went wrong");
			e1.printStackTrace();
		}
			
		}
		else {
			JOptionPane.showMessageDialog(null,
	                "Please ensure no details are left blank and password matches retyped password ",
	                "PopUp Dialog",
	                JOptionPane.INFORMATION_MESSAGE);
		}
		
	};
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeDetails frame = new EmployeeDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeDetails() {
		setTitle("Employee details");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 575, 455);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Number");
		lblNewLabel.setBounds(10, 53, 95, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblBranchid = new JLabel("BranchID");
		lblBranchid.setBounds(10, 84, 95, 14);
		contentPane.add(lblBranchid);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 109, 95, 14);
		contentPane.add(lblName);
		
		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setBounds(10, 141, 95, 14);
		contentPane.add(lblSurname);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(10, 177, 95, 14);
		contentPane.add(lblAddress);
		
		JLabel lblContactNumber = new JLabel("Contact Number");
		lblContactNumber.setBounds(10, 205, 95, 14);
		contentPane.add(lblContactNumber);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 233, 95, 14);
		contentPane.add(lblPassword);
		
		JLabel lblRetypePassword = new JLabel("Retype Password");
		lblRetypePassword.setBounds(10, 264, 95, 14);
		contentPane.add(lblRetypePassword);
		
		txtID = new JTextField();
		txtID.setEditable(false);
		txtID.setBounds(114, 50, 326, 20);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtBranch = new JTextField();
		txtBranch.setEditable(false);
		txtBranch.setColumns(10);
		txtBranch.setBounds(115, 81, 325, 20);
		contentPane.add(txtBranch);
		
		txtName = new JTextField();
		txtName.setEditable(false);
		txtName.setColumns(10);
		txtName.setBounds(115, 106, 325, 20);
		contentPane.add(txtName);
		
		txtSurname = new JTextField();
		txtSurname.setEditable(false);
		txtSurname.setColumns(10);
		txtSurname.setBounds(115, 138, 325, 20);
		contentPane.add(txtSurname);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(115, 174, 325, 20);
		contentPane.add(txtAddress);
		
		txtContact = new JTextField();
		txtContact.setColumns(10);
		txtContact.setBounds(115, 202, 325, 20);
		contentPane.add(txtContact);
		
		txtPassword = new JTextField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(115, 230, 325, 20);
		contentPane.add(txtPassword);
		
		txtRetype = new JTextField();
		txtRetype.setColumns(10);
		txtRetype.setBounds(115, 261, 325, 20);
		contentPane.add(txtRetype);
		
		JButton btnNewButton = new JButton("Update Details");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateDetails();
			}
		});
		btnNewButton.setBounds(114, 310, 326, 23);
		contentPane.add(btnNewButton);
		
		EmployeeLogin el=new EmployeeLogin();
		ID=el.getId();
		password=el.getPassword();
		
		getDetails(ID, password);
		
		
	}

}
