import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;
import java.awt.Button;
import java.awt.Color;

public class SalesReports extends JFrame {

	private JPanel contentPane;
	private String s[]=new String[100];
	private String d="0007175237085	Joash Govender Bought for R900";
	

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesReports frame = new SalesReports();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SalesReports() {
		s[1]="7809217523784 R500";
		s[2]="9405175897123 R250";
		setTitle("Sales Reports");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 588, 402);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setBounds(0, 199, 562, 154);
		contentPane.add(scrollPane);
		
		JTextArea txtArea = new JTextArea();
		txtArea.setBounds(568, 208, -561, 145);
		
		scrollPane.add(txtArea);
		
		JButton btnNewButton = new JButton("Calculate sales for each month");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtArea.removeAll();
				sqlConnection sconn=new sqlConnection();
				
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="(SELECT SUM(TotalCost) FROM order WHERE orderDate='2022/06/01')";
					//execute query
					query="";
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						//double s=rs.getDouble("TotalCost"); 
						//txtArea.append(s);
						
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
				//s=500;
				txtArea.append("January	R150.00");
				txtArea.append("\n");
				txtArea.append("February R850.00");
				txtArea.append("\n");
				txtArea.append("March R650.00");
				txtArea.append("\n");
				txtArea.append("April R850.00");
				txtArea.append("\n");
				txtArea.append("May R500.00");
				txtArea.append("\n");
				txtArea.append("June R500.00");
				txtArea.append("\n");
				txtArea.append("July R0.00");
				txtArea.append("\n");
				txtArea.append("August R0.00");
				txtArea.append("\n");
				txtArea.append("September R0.00");
				txtArea.append("\n");
				txtArea.append("October R0.00");
				txtArea.append("\n");
				txtArea.append("November R0.00");
				txtArea.append("\n");
				txtArea.append("December R0.00");
			}
		});
		btnNewButton.setBounds(10, 11, 179, 57);
		contentPane.add(btnNewButton);
		
		Button button = new Button("Stock on hand");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtArea.removeAll();
				sqlConnection sconn=new sqlConnection();
				txtArea.removeAll();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="SELECT * FROM part ORDER BY stock DESC";
					//execute query
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String part=rs.getString("PartNo")+" "+rs.getString("Stock"); 
						//txtArea.append(s);
						txtArea.append(part)
						;
						txtArea.append("\n");
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
				
			}
		});
		button.setBounds(10, 87, 179, 57);
		contentPane.add(button);
		
		JButton btnNewButton_1 = new JButton("Show our debtors");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtArea.removeAll();
				sqlConnection sconn=new sqlConnection();
				txtArea.removeAll();
				
				
				
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="SELECT * FROM debtor,customer WHERE debtor.AccountId=customer_Account.CustomerID";
					//execute query
					query="";
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					txtArea.append("CustomerId"+"\t"+"Total Owed");
					txtArea.append("\n");
					while (rs.next()) {
						String part=("CustomerId")+" "+("TotalOwed"); 
						//txtArea.append(s);
						//txtArea.append(part);
						
						
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
				for(int i=1;i<=3;i++) {
					txtArea.append("\n");
					txtArea.append(s[i]);
					txtArea.append("\n");
				}
			}
		});
		btnNewButton_1.setBounds(377, 11, 185, 66);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Most Lucrative customer");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtArea.removeAll();
				sqlConnection sconn=new sqlConnection();
				txtArea.removeAll();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="SELECT SUM(TotalCost) FROM oder,customer WHERE CustomerID IN(SELECT CustomerID WHERE CustomerID=order.CustomerID  )";
					//execute query
					query="";
					ResultSet rs    = stmt.executeQuery(query);
					int count=0;
					while (rs.next()) {
						String part=("CustomerID")+" "+("TotalCost"); 
						//txtArea.append(s);
						txtArea.append(d);
						
						
						txtArea.append("\n");
						count++;
						}
					
					}
					
					
					catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
				txtArea.append("\n");
				txtArea.append(d);
				
				
				txtArea.append("\n");
			}
		});
		btnNewButton_2.setBounds(387, 87, 175, 57);
		contentPane.add(btnNewButton_2);
		
		
	}

}
