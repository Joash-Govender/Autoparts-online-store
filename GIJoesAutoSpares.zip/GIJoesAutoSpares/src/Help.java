import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class Help extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void newScreen() throws Exception {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Help frame = new Help();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Help()throws Exception {
		getContentPane().setLayout(null);
		
		
		
		setTitle("Help");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 553, 358);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea txtArea = new JTextArea();
		txtArea.setWrapStyleWord(true);
		txtArea.setLineWrap(true);
		txtArea.setBounds(10, 55, 517, 253);
		getContentPane().add(txtArea);
		
		JLabel lblNewLabel = new JLabel("Help");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 60));
		lblNewLabel.setBounds(0, 11, 207, 57);
		contentPane.add(lblNewLabel);
		
		
		
		  // Passing the path to the file as a parameter
        //FileReader fr = new FileReader("C:\\Users\\joash\\Documents\\Java Projects\\GIJoesAutoSpares\\help.txt");
 
        // Declaring loop variable
		 File file = new File("C:\\Users\\joash\\Documents\\Java Projects\\GIJoesAutoSpares\\help.txt");
		  Scanner sc = new Scanner(file);
		 
		    while (sc.hasNextLine())
		      txtArea.append(sc.nextLine());
		       txtArea.append("\n");
	}
}
