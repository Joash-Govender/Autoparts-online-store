import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class Home {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setForeground(Color.RED);
		frame.getContentPane().setForeground(Color.BLACK);
		frame.setBounds(100, 100, 594, 396);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnGuest = new JButton("Guest");
		btnGuest.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnGuest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ItemLookUp it=new ItemLookUp();
				it.newScreen();
			}
		});
		btnGuest.setForeground(Color.BLACK);
		btnGuest.setBounds(81, 65, 387, 57);
		frame.getContentPane().add(btnGuest);
		
		JButton btnNewButton = new JButton("Customer");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerHome ch=new CustomerHome();
				ch.newScreen();
			}
		});
		btnNewButton.setBounds(81, 133, 387, 55);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnEmployee = new JButton("Employee");
		btnEmployee.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeLogin el=new EmployeeLogin();
				el.newScreen();
			}
		});
		btnEmployee.setBounds(81, 199, 387, 48);
		frame.getContentPane().add(btnEmployee);
		
		JButton btnAdmin = new JButton("Admin");
		btnAdmin.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin adl=new AdminLogin();
				adl.newScreen();
			}
		});
		btnAdmin.setBounds(81, 258, 387, 54);
		frame.getContentPane().add(btnAdmin);
		
		JButton btnHelp = new JButton("Help");
		btnHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Help h;
				try {
					h = new Help();
					h.newScreen();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnHelp.setBounds(10, 323, 89, 23);
		frame.getContentPane().add(btnHelp);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 System. exit(0);
				
			}
		});
		btnExit.setBounds(479, 323, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JLabel lblNewLabel = new JLabel("GI Joes's AutoSpares");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblNewLabel.setBounds(81, 0, 416, 43);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Looking for spares? We've got time to spare!");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(67, 40, 501, 23);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
