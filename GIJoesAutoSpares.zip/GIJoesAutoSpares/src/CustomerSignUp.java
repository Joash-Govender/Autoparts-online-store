import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import java.awt.Color;

public class CustomerSignUp extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtName;
	private JTextField txtSurname;
	private JTextField txtAddress;
	private JTextField txtContact;
	private JTextField txtEmail;
	private JTextField txtPassword;
	private JTextField txtRetype;

	
	
	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerSignUp frame = new CustomerSignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerSignUp() {
		setTitle("Create Customer Account");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 673, 419);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Number");
		lblNewLabel.setBounds(10, 54, 73, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 79, 73, 14);
		contentPane.add(lblName);
		
		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setBounds(10, 110, 73, 14);
		contentPane.add(lblSurname);
		
		JLabel lblIdNumber = new JLabel("Address");
		lblIdNumber.setBounds(10, 135, 73, 14);
		contentPane.add(lblIdNumber);
		
		JLabel lblContactNumber = new JLabel("Contact Number");
		lblContactNumber.setBounds(0, 166, 83, 14);
		contentPane.add(lblContactNumber);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(10, 193, 73, 14);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 218, 73, 14);
		contentPane.add(lblPassword);
		
		JLabel lblRetypePassword = new JLabel("Retype Password");
		lblRetypePassword.setBounds(0, 243, 97, 14);
		contentPane.add(lblRetypePassword);
		
		txtId = new JTextField();
		txtId.setBounds(93, 51, 483, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(93, 76, 483, 20);
		contentPane.add(txtName);
		
		txtSurname = new JTextField();
		txtSurname.setColumns(10);
		txtSurname.setBounds(93, 107, 483, 20);
		contentPane.add(txtSurname);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(93, 132, 483, 20);
		contentPane.add(txtAddress);
		
		txtContact = new JTextField();
		txtContact.setColumns(10);
		txtContact.setBounds(93, 163, 483, 20);
		contentPane.add(txtContact);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(93, 190, 483, 20);
		contentPane.add(txtEmail);
		
		txtPassword = new JTextField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(93, 215, 483, 20);
		contentPane.add(txtPassword);
		
		txtRetype = new JTextField();
		txtRetype.setColumns(10);
		txtRetype.setBounds(93, 240, 483, 20);
		contentPane.add(txtRetype);
		
		JLabel lblNewLabel_1 = new JLabel("Payment Type");
		lblNewLabel_1.setBounds(10, 280, 83, 14);
		contentPane.add(lblNewLabel_1);
		
		JRadioButton rgbCash = new JRadioButton("Cash");
		rgbCash.setSelected(true);
		rgbCash.setBounds(93, 276, 58, 23);
		contentPane.add(rgbCash);
		
		JRadioButton rgbAccount = new JRadioButton("Account");
		rgbAccount.setBounds(151, 276, 109, 23);
		contentPane.add(rgbAccount);
		ButtonGroup group=new ButtonGroup();
		group.add(rgbAccount);
		group.add(rgbCash);

		JCheckBox chkId = new JCheckBox("");
		chkId.setSelected(true);
		chkId.setBounds(582, 51, 97, 23);
		contentPane.add(chkId);
		
		JCheckBox chkName = new JCheckBox("");
		chkName.setSelected(true);
		chkName.setBounds(582, 75, 97, 23);
		contentPane.add(chkName);
		
		JCheckBox chkSurname = new JCheckBox("");
		chkSurname.setSelected(true);
		chkSurname.setBounds(582, 106, 97, 23);
		contentPane.add(chkSurname);
		
		JCheckBox chkAddress = new JCheckBox("");
		chkAddress.setSelected(true);
		chkAddress.setBounds(582, 131, 97, 23);
		contentPane.add(chkAddress);
		
		JCheckBox chkContact = new JCheckBox("");
		chkContact.setSelected(true);
		chkContact.setBounds(582, 162, 97, 23);
		contentPane.add(chkContact);
		
		JCheckBox chkEmail = new JCheckBox("");
		chkEmail.setSelected(true);
		chkEmail.setBounds(582, 189, 97, 23);
		contentPane.add(chkEmail);
		
		JCheckBox chkPassword = new JCheckBox("");
		chkPassword.setSelected(true);
		chkPassword.setBounds(582, 214, 97, 23);
		contentPane.add(chkPassword);
		
		JCheckBox chkRetype = new JCheckBox("");
		chkRetype.setSelected(true);
		chkRetype.setBounds(582, 239, 97, 23);
		contentPane.add(chkRetype);
		
		JButton btnNewButton = new JButton("Create Account");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ID,Name,Surname,Email,Contact,Password,retype,address,AccType;
				ID=txtId.getText();
				Name=txtName.getText();
				Surname=txtSurname.getText();
				Email=txtEmail.getText();
				Contact=txtContact.getText();
				Password=txtPassword.getText();
				retype=txtRetype.getText();
				address=txtAddress.getText();
				if(rgbAccount.isSelected()) {
					AccType="account";
				}
				else  {
					AccType="cash";
				}
				boolean bID,bName,bSurname,bEmail,bContact,bPassword,bretype,baddress;
				bID=true;
				bName=true;
				bSurname=true;
				bEmail=true;
				bContact=true;
				bPassword=true;
				bretype=true;
				baddress=true;
				if (ID.length()<13) {bID=false;chkId.setSelected(false);}
				if(Name.length()<1 ) {bName=false;chkName.setSelected(false);}
				if(Surname.length()<1) {bSurname=false;chkSurname.setSelected(false);}
				if(Email.length()<1) {bEmail=false;chkEmail.setSelected(false);}
				if(Contact.length()<10) {bContact=false;chkContact.setSelected(false);}
				if(Password.length()<1 || Password.length()<=3) {bPassword=false;chkPassword.setSelected(false);}
				if(!Password.equals(retype)) {bretype=false;chkRetype.setSelected(false);}
				if(address.length()<5) {baddress=false;chkAddress.setSelected(false);}
				
				//create account if inputs valid
				if (bID &&bName&&bSurname&&bEmail&&bContact&&bPassword&&bretype&&baddress) {
					sqlConnection sconn=new sqlConnection();
					
					try {
						
						Connection conn=sconn.getConnection();
						//create a statement object
						Statement stmt=conn.createStatement();
						//write query
						String query="INSERT INTO customer(CustomerId,Name,Surname, Email, ContactNo,Password,Address, CustomerType) VALUES ('"+ID+ "','" +Name+ "','" +Surname+ "','" +Email+ "','" +Contact+ "','" +Password+ "','" +address+ "','" +AccType +"')";
						//execute query
						stmt.executeUpdate(query);
						
						
						System.out.println("Sign up sucessful");
						
						
							
						}
						
						
						catch (Exception e1) {
							// TODO: handle exception
							System.out.println("something went wrong");
							e1.printStackTrace();
						}
					
				}
				
			}
		});
		btnNewButton.setBounds(236, 346, 141, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("validate inputs");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chkId.setSelected(true);
				chkName.setSelected(true);
				chkSurname.setSelected(true);
				chkEmail.setSelected(true);
				chkContact.setSelected(true);
				chkPassword.setSelected(true);
				chkRetype.setSelected(true);
				chkAddress.setSelected(true);
				String ID,Name,Surname,Email,Contact,Password,retype,address,AccType;
				ID=txtId.getText();
				Name=txtName.getText();
				Surname=txtSurname.getText();
				Email=txtEmail.getText();
				Contact=txtContact.getText();
				Password=txtPassword.getText();
				retype=txtRetype.getText();
				address=txtAddress.getText();
				if(rgbCash.isSelected()) {
					AccType="cash";
				}
				else if(rgbAccount.isSelected()) {
					AccType="account";
				}
				boolean bID,bName,bSurname,bEmail,bContact,bPassword,bretype,baddress;
				bID=true;
				bName=true;
				bSurname=true;
				bEmail=true;
				bContact=true;
				bPassword=true;
				bretype=true;
				baddress=true;
				if (ID.length()<13) {bID=false;chkId.setSelected(false);}
				if(Name.length()<1 ) {bName=false;chkName.setSelected(false);}
				if(Surname.length()<1) {bSurname=false;chkSurname.setSelected(false);}
				if(Email.length()<1) {bEmail=false;chkEmail.setSelected(false);}
				if(Contact.length()<10) {bContact=false;chkContact.setSelected(false);}
				if(Password.length()<1 || Password.length()<=3) {bPassword=false;chkPassword.setSelected(false);}
				if(!Password.equals(retype)) {bretype=false;chkRetype.setSelected(false);}
				if(address.length()<5) {baddress=false;chkAddress.setSelected(false);}
				
			}
		});
		btnNewButton_1.setBounds(236, 312, 141, 23);
		contentPane.add(btnNewButton_1);
		
	}
}
