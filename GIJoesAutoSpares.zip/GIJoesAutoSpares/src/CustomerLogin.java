import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.Font;
import java.awt.Color;

public class CustomerLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdNum;
	private JTextField txtPassword;
	private JTextField txtDisplay;
	private static String IdNum,Password;
	/**
	 * Launch the application.
	 */
	public String getID() {
		return txtIdNum.getText();
	}
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerLogin frame = new CustomerLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerLogin() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 538, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Number:");
		lblNewLabel.setBounds(72, 44, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(72, 97, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		txtIdNum = new JTextField();
		txtIdNum.setFont(UIManager.getFont("PasswordField.font"));
		txtIdNum.setBounds(128, 41, 199, 20);
		contentPane.add(txtIdNum);
		txtIdNum.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(128, 94, 199, 20);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IdNum=txtIdNum.getText();
				IdNum.replaceAll("\\s", "");
				Password=txtPassword.getText();
				Password.replaceAll("\\s", "");
				System.out.println("input  "+IdNum+" "+Password);
				sqlConnection sconn=new sqlConnection();
				
				try {
					
					Connection conn=sconn.getConnection();
					//create a statement object
					Statement stmt=conn.createStatement();
					//write query
					String query="SELECT CustomerId,Password  FROM customer";
					//execute query
					ResultSet rs=stmt.executeQuery(query);
					
					//display results
					
					
					
					
					while (rs.next()) {
						String custID=rs.getString("CustomerId");
						String custPassword=rs.getString("Password");
						custID.replaceAll("\\s", "");
						custPassword.replaceAll("\\s", "");
						System.out.println(custID+" "+custPassword);
						
						
						
						if (IdNum.equals(custID) ){
							if (Password.equals(custPassword) ) {
								IdNum=custID;
								txtDisplay.setForeground(Color.green);
								txtDisplay.setText("Correct!!!");
								
								CustomerShop cs=new CustomerShop();
								cs.newScreen();
								break;
								
							}
							
							
						}
						else {
							txtDisplay.setForeground(Color.red);
							txtDisplay.setText("Id number or password Incorrect");
							
							
							
						}
					
						
						
					}
					
					} catch (Exception e1) {
						// TODO: handle exception
						System.out.println("something went wrong");
						e1.printStackTrace();
					}
			
			
						
			}
		});
		btnNewButton.setBounds(128, 157, 199, 23);
		contentPane.add(btnNewButton);
		
		txtDisplay = new JTextField();
		txtDisplay.setEditable(false);
		txtDisplay.setBounds(128, 125, 199, 21);
		contentPane.add(txtDisplay);
		txtDisplay.setColumns(10);
	}
}
