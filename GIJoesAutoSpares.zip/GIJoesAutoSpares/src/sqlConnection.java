import java.sql.Connection;
import java.sql.DriverManager;

public class sqlConnection {
	
	public static Connection getConnection() {
		try {
			//load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//create connection object
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/GIJoesAutospares","root","J1o2a3s4h5$");
			
			//now connection is established
			System.out.println("Connection established");
			
			//close connection
			return conn;
			
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error driver not found");
			e.printStackTrace();
			return null;
		}
		
		
		
	}
	
	
    
	
}
